var http = require('http');

http.createServer(
    function (req,res){
        res.writeHead(200, {'Content-Type':'text/html'});
        res.end('Seja bem vindo!');
    }
).listen(8001);

console.log("Servidor rodando na porta http://localhost:8001")