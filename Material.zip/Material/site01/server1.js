const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) =>{


    fs.readFile(
        'index.html',
        (err, data) => {
            if (err){
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end("Erro ao abrir o arquivo.");
                return;
            }
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end(data);
        }
    );
});

server.listen(5000, ()=>{
    console.log('Sevidor de pe na porta http://localhost:5000');
})