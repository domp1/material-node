const express = require('express');
const app = express();

app.get("/",function(req,res){
    res.send("Index do meu servidor NodeJs utilizando o pacote express");
});

app.get("/sobre",function(req,res){
    res.send("Pagina SOBRE do servidor NodeJs utilizando o pacote express");
});

app.get("/noticias",function(req,res){
    res.send("Pagina de noticias do servidor NodeJs utilizando o pacote express");
});

app.listen(8000, function(){
    console.log("Servidor usando o express rodando em http://localhost:8000");
});