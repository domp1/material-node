const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({extended: true}));

app.get('/', (req, res) => {
    fs.readFile(
        'index.html',
        (err, data) => {
            if (err){
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end("Erro ao abrir o arquivo.");
                return;
            }
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end(data);
        }
    );
}); 

app.get('/soma', (req, res) => {
    fs.readFile(
        'form2.html',
        (err, data) => {
            if (err){
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end("Erro ao abrir o arquivo.");
                return;
            }
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end(data);
        }
    );
});

app.post('/form1', (req, res) =>{
    const { nome, sobrenome} = req.body;
    console.log(`Nome:${nome} \nSobrenome:${sobrenome}`);
    res.send(`Bem vindo ${nome} ${sobrenome}!`);
});

app.post('/soma', (req, res) =>{
    const { valA, valB} = req.body; 
    let v1 = parseInt(`${valA}`);
    let v2 = parseInt(`${valB}`);
    res.send('A soma dos dois valores é '+(v1+v2));
});
 
app.listen(8000, ()=> {
    console.log(`Acesse em http://localhost:8000`);
});