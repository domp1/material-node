const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({extended: true}));

app.get('/', (req, res) => {
    fs.readFile(
        'index.html',
        (err, data) => {
            if (err){
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end("Erro ao abrir o arquivo.");
                return;
            }
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.end(data);
        }
    );
}); 
  
app.post('/login', (req, res) =>{
    //constantes de login e senha
    const loginDefault = 'luiz';
    const senhaDefault = 'senai';

    const { nome, senha} = req.body;
    let login = `${nome}`;
    let pass = `${senha}`;

    if(login == loginDefault && pass == senhaDefault){
        console.log('Funciona!');
        fs.readFile(
            'main.html',
            (err, data) => {
                if (err){
                    res.writeHead(500, {'Content-Type': 'text/plain'});
                    res.end("Erro ao abrir o arquivo.");
                    return;
                }
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.end(data);
            }
        );
    }else{
        console.log('Error');
        fs.readFile(
            'index.html',
            (err, data) => {
                if (err){
                    res.writeHead(500, {'Content-Type': 'text/plain'});
                    res.end("Erro ao abrir o arquivo.");
                    return;
                }
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.end(data);
            }
        );
    }  
});
 
app.listen(8000, ()=> {
    console.log(`Acesse em http://localhost:8000`);
});