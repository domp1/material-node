const axios = require('axios');
const express = require('express');
const app = express();
const fs = require('fs');
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

function FarenheittoCelcius(val){
    return Math.round(100*((val - 32) * (5/9)))/100
}


async function fetchData(city) {
    try {
        const response = await axios.get(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${city}?key=2YB5NSGEUG234URKH5PGHAYVW`);
        const data = response.data;

        console.log('Dados recebidos da API');
        let cidad = data.resolvedAddress;
        let descricao = data.description;
        let dia = data.days[0].datetime;
        let max = FarenheittoCelcius(data.days[0].tempmax);
        let min = FarenheittoCelcius(data.days[0].tempmin);

        app.post('/clima', (req, res) =>{

            const {cidade} = req.body;
            let city = `${cidade}`;
        
            //const { nome, sobrenome} = req.body;
            console.log(city);
        
            
        
            fs.readFile(
                'index.html',
                (err, data) => {
                    if (err){
                        res.writeHead(500, {'Content-Type': 'text/plain'});
                        res.end("Erro ao abrir o arquivo.");
                        return;
                    }

                     // Dados que você deseja passar para a página
                    const myData = JSON.stringify({ titulo: `${cidad}`, subtitulo: `${descricao}`, tempo: `${dia}`, maxima: `${max}`, minima: `${min}`});
                    console.log(myData);
        
                    // Embutindo dados no HTML
                    const html = data.toString().replace('</head>', `<script>const serverData = ${myData};</script></head>`);
        
               
                    res.writeHead(200, {'Content-Type': 'text/html'});
                    res.end(html);
                });
            });
            
            
        } catch(error){
            console.log("Erro ao obter dados da API: ", error);
        };
    };
    
    app.get('/', (req, res) => {
        fs.readFile(
            'index.html',
            (err, data) => {
                if (err){
                    res.writeHead(500, {'Content-Type': 'text/plain'});
                    res.end("Erro ao abrir o arquivo.");
                    return;
                }
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.end(data);
            }
        );
    })
    
fetchData();


app.listen(8000, () =>{
    console.log('Servidor ativo em https://localhost:8000');
})
